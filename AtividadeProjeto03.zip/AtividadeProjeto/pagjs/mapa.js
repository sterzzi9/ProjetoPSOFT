document.addEventListener("DOMContentLoaded", () => {
    // --- 1. REFERÊNCIAS DE ELEMENTOS ---

    // Sidebar e Overlay
    const sidebar = document.getElementById('menu-lateral');
    const overlay = document.getElementById('fundo-escuro');
    const btnAbrir = document.getElementById('abrir-menu');
    const btnFechar = document.getElementById('fechar-menu');

    // Perfil
    const btnPerfil = document.getElementById('abrir-perfil');
    const menuPerfil = document.getElementById('perfil-menu');

    // Modal de Relatos
    const modal = document.getElementById('modal-fundo');
    const btnRelatar = document.getElementById('btn-relatar-waze');
    const btnCancelar = document.getElementById('btnCancelar');
    const btnConfirmar = document.getElementById('btnConfirmar');
    const campoSelecao = document.getElementById('campo-selecao');
    const gradeIcones = document.getElementById('grade-icones');
    const labelSelecao = document.getElementById('label-selecao');
    const inputOcultoTipo = document.getElementById('valor-problema');

    // Busca/Filtro
    const inputBusca = document.getElementById('filtro');
    const listaSugestoes = document.getElementById('lista');

    // --- 2. LOGICA DA SIDEBAR (MENU LATERAL) ---
    const toggleSidebar = () => {
        if (sidebar && overlay) {
            sidebar.classList.toggle('aberto');
            overlay.classList.toggle('ativo');
        }
    };

    if (btnAbrir) btnAbrir.onclick = toggleSidebar;
    if (btnFechar) btnFechar.onclick = toggleSidebar;
    if (overlay) overlay.onclick = toggleSidebar;

    // --- 3. LOGICA DO PERFIL (MENU SUSPENSO) ---
    if (btnPerfil) {
        btnPerfil.onclick = (e) => {
            e.stopPropagation();
            menuPerfil.classList.toggle('mostrar');
        };
    }

    // --- 4. LOGICA DO MODAL DE RELATOS ---

    // Abrir e Fechar Modal
    if (btnRelatar) {
        btnRelatar.onclick = () => modal.classList.remove('modal-escondido');
    }
    if (btnCancelar) {
        btnCancelar.onclick = () => {
            modal.classList.add('modal-escondido');
            limparFormulario();
        };
    }

    // Mostrar Grade de Ícones
    if (campoSelecao) {
        campoSelecao.onclick = () => gradeIcones.classList.toggle('hidden');
    }

    // Selecionar um Ícone da Grade
    document.querySelectorAll('.opcao-icon').forEach(opcao => {
        opcao.onclick = function () {
            const nome = this.getAttribute('data-nome');
            labelSelecao.innerText = nome;
            inputOcultoTipo.value = nome;
            gradeIcones.classList.add('hidden');
        };
    });

    // --- 5. LOGICA DO BOTÃO CONFIRMAR ---
    if (btnConfirmar) {
        btnConfirmar.onclick = () => {
            const tipo = inputOcultoTipo.value;
            const descricao = document.querySelector('input[placeholder="Descrição do problema"]').value;
            const localizacao = document.querySelector('input[placeholder="Localização do problema"]').value;
            const horario = document.querySelector('.time-input').value;

            // Validação simples
            if (!tipo || tipo === "") {
                alert("⚠️ Por favor, escolha um tipo de problema clicando no ícone.");
                return;
            }
            if (!descricao.trim() || !localizacao.trim()) {
                alert("⚠️ Por favor, preencha a descrição e a localização.");
                return;
            }

            // Exemplo de saída (aqui você faria o envio para o servidor)
            console.log("Enviando Relato:", {
                tipo: tipo,
                descricao: descricao,
                localizacao: localizacao,
                horario: horario
            });

            alert("✅ Problema relatado com sucesso!");
            modal.classList.add('modal-escondido');
            limparFormulario();
        };
    }

    // Função para limpar os campos do modal
    function limparFormulario() {
        document.querySelector('input[placeholder="Descrição do problema"]').value = "";
        document.querySelector('input[placeholder="Localização do problema"]').value = "";
        document.querySelector('.time-input').value = "";
        labelSelecao.innerText = "Clique para escolher o ícone...";
        inputOcultoTipo.value = "";
        gradeIcones.classList.add('hidden');
    }

    // --- 6. LOGICA DA BUSCA (FILTRO) ---
    if (inputBusca) {
        inputBusca.oninput = function () {
            const termo = inputBusca.value.toLowerCase().trim();
            const itens = listaSugestoes.querySelectorAll('li');
            let achou = false;

            itens.forEach(item => {
                const texto = item.textContent.toLowerCase();
                if (termo.length > 0 && texto.includes(termo)) {
                    item.style.display = "block";
                    achou = true;
                } else {
                    item.style.display = "none";
                }
            });

            // Mostra a lista (ul) apenas se houver algo digitado e algo encontrado
            listaSugestoes.style.display = achou ? "block" : "none";
        };
    }

    // --- 7. FECHAR ELEMENTOS AO CLICAR FORA ---
    window.onclick = (e) => {
        // Fecha o menu de perfil se clicar fora da caixa de perfil
        if (menuPerfil && !e.target.closest('.perfil-caixa')) {
            menuPerfil.classList.remove('mostrar');
        }

        // Fecha a lista de busca se clicar fora da barra de ferramentas
        if (listaSugestoes && !e.target.closest('.barra-ferramentas')) {
            listaSugestoes.style.display = "none";
        }

        // Fecha o modal se clicar no fundo escuro dele
        if (e.target === modal) {
            modal.classList.add('modal-escondido');
            limparFormulario();
        }
    };
});