document.addEventListener("DOMContentLoaded", () => {
    
    // --- LÓGICA DO MENU LATERAL ---
    const btnAbrir = document.getElementById('abrir-menu');
    const btnFechar = document.getElementById('fechar-menu');
    const sidebar = document.getElementById('menu-lateral');
    const overlay = document.getElementById('fundo-escuro');

    function abrirMenu() {
        sidebar.classList.add('aberto');
        overlay.classList.add('ativo');
    }

    function fecharMenu() {
        sidebar.classList.remove('aberto');
        overlay.classList.remove('ativo');
    }

    // Eventos do Menu
    if(btnAbrir) btnAbrir.addEventListener('click', abrirMenu);
    if(btnFechar) btnFechar.addEventListener('click', fecharMenu);
    if(overlay) overlay.addEventListener('click', fecharMenu);


    // --- LÓGICA DAS OCORRÊNCIAS ---
    const container = document.getElementById('container-ocorrencias');
    const inputBusca = document.getElementById('busca');
    const selectFiltro = document.getElementById('filtro-tipo');

    const minhasOcorrencias = [
        { tipo: "Incêndio", endereco: "Rua Alameda dos Ventos, 123", data: "20/05/2026", hora: "10:56", icone: "🔥" },
        { tipo: "Buraco", endereco: "Avenida da Coroa, 45", data: "12/05/2026", hora: "18:31", icone: "🕳️" },
        { tipo: "Mato alto", endereco: "Praça do Imperador", data: "29/04/2026", hora: "05:24", icone: "🌿" },
        { tipo: "Vazamento de esgoto", endereco: "Rua Sete de Setembro", data: "01/06/2026", hora: "14:20", icone: "🤢" }
    ];

    function renderizar(lista) {
        if (!container) return; // Evita erro se o container não existir
        container.innerHTML = "";

        if (lista.length === 0) {
            container.innerHTML = `<p style="text-align:center; padding:20px; color:#666;">Nenhuma ocorrência encontrada para esse filtro.</p>`;
            return;
        }

        lista.forEach(item => {
            const card = document.createElement('div');
            card.className = 'card';
            card.innerHTML = `
                <div class="card-info">
                    <p><strong>${item.tipo}</strong></p>
                    <p>📍 ${item.endereco}</p>
                    <p>📅 ${item.data} às ${item.hora}</p>
                </div>
                <div class="card-icon">${item.icone}</div>
            `;
            container.appendChild(card);
        });
    }

    // Função que combina os dois filtros (Texto + Categoria)
    function aplicarFiltros() {
        const termo = inputBusca.value.toLowerCase();
        const categoria = selectFiltro.value;

        const resultado = minhasOcorrencias.filter(item => {
            const matchesTexto = item.endereco.toLowerCase().includes(termo) ||
                item.tipo.toLowerCase().includes(termo);
            const matchesCategoria = categoria === "" || item.tipo === categoria;

            return matchesTexto && matchesCategoria;
        });

        renderizar(resultado);
    }

    // Eventos de Busca
    if(inputBusca && selectFiltro) {
        inputBusca.addEventListener('input', aplicarFiltros);
        selectFiltro.addEventListener('change', aplicarFiltros);
    }

    // Renderização inicial
    renderizar(minhasOcorrencias);
});