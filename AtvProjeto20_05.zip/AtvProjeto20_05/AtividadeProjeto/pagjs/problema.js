document.addEventListener("DOMContentLoaded", function () {
    // Captura os elementos para controlar a transição do formulário
    const modalFundo = document.getElementById("modal-fundo");
    const btnRelatarWaze = document.getElementById("btn-relatar-waze");
    const btnCancelar = document.getElementById("btnCancelar");
    const btnConfirmar = document.getElementById("btnConfirmar");

    // Elementos da sua caixa de seleção de ícones (mantidos idênticos)
    const campoSelecao = document.getElementById("campo-selecao");
    const gradeIcones = document.getElementById("grade-icones");
    const labelSelecao = document.getElementById("label-selecao");
    const valorProblema = document.getElementById("valor-problema");
    const opcoesIcones = document.querySelectorAll(".opcao-icon");

    // 1. Ao clicar no botão "Relatar Problema" verde do mapa, a caixinha aparece
    if (btnRelatarWaze) {
        btnRelatarWaze.addEventListener("click", function () {
            modalFundo.classList.remove("modal-escondido");
        });
    }

    // 2. Ao clicar em "Cancelar", fecha o formulário e volta pro mapa limpo
    if (btnCancelar) {
        btnCancelar.addEventListener("click", function () {
            modalFundo.classList.add("modal-escondido");
        });
    }

    // 3. Ao clicar em "Confirmar", fecha o formulário
    if (btnConfirmar) {
        btnConfirmar.addEventListener("click", function () {
            alert("Problema reportado com sucesso!");
            modalFundo.classList.add("modal-escondido");
        });
    }

    // 4. LÓGICA DE SELEÇÃO DOS ÍCONES (Mantida exatamente como você criou)
    if (campoSelecao && gradeIcones) {
        campoSelecao.addEventListener("click", function () {
            gradeIcones.classList.toggle("hidden");
        });

        opcoesIcones.forEach(opcao => {
            opcao.addEventListener("click", function () {
                const nomeProblema = this.getAttribute("data-nome");
                const imgSrc = this.querySelector("img").src;

                // Atualiza o campo com a opção selecionada
                labelSelecao.innerHTML = `<img src="${imgSrc}" style="width:20px; margin-right:8px; vertical-align:middle;"> ${nomeProblema}`;
                valorProblema.value = nomeProblema;

                // Fecha a grade de ícones
                gradeIcones.classList.add("hidden");
            });
        });
    }
});s