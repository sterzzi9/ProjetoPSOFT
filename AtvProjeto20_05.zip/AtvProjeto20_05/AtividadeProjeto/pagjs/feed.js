document.addEventListener("DOMContentLoaded", function() {
    const estrelas = document.querySelectorAll("#rating-stars span");
    const inputRating = document.querySelector("#rating-value");

    estrelas.forEach(estrela => {
        estrela.addEventListener("click", function() {
            const valor = this.getAttribute("data-value");
            
            // 1. Atualiza o valor no input escondido
            inputRating.value = valor;

            // 2. Remove a cor ativa de todas
            estrelas.forEach(s => s.classList.remove("active"));

            // 3. Adiciona a cor ativa na clicada e nas anteriores
            estrelas.forEach(s => {
                if (s.getAttribute("data-value") <= valor) {
                    s.classList.add("active");
                }
            });
            
            console.log("Avaliação selecionada: " + valor);
        });
    });
});