document.addEventListener('DOMContentLoaded', () => {
    const inputFiltro = document.getElementById('filtro');
    const listaSugestoes = document.getElementById('lista');
    const itensProblemas = listaSugestoes.querySelectorAll('li');

    // 1. FILTRAR ENQUANTO DIGITA
    inputFiltro.addEventListener('input', () => {
        const valorDigitado = inputFiltro.value.toLowerCase();

        if (valorDigitado.length > 0) {
            listaSugestoes.style.display = 'block'; // Mostra a lista

            let encontrouAlgum = false;

            itensProblemas.forEach(item => {
                const textoItem = item.textContent.toLowerCase();

                if (textoItem.includes(valorDigitado)) {
                    item.style.display = 'block';
                    encontrouAlgum = true;
                } else {
                    item.style.display = 'none';
                }
            });

            // Se nada bater com a busca, esconde a lista
            if (!encontrouAlgum) {
                listaSugestoes.style.display = 'none';
            }

        } else {
            listaSugestoes.style.display = 'none'; // Esconde se apagar tudo
        }
    });

    // 2. SELECIONAR UM PROBLEMA DA LISTA
    itensProblemas.forEach(item => {
        item.addEventListener('click', () => {
            // Coloca o nome do problema no input
            inputFiltro.value = item.textContent;
            // Esconde a lista
            listaSugestoes.style.display = 'none';

            console.log("Filtro aplicado: " + item.textContent);
            // DICA: Aqui você poderá futuramente disparar uma função 
            // para mostrar apenas esses ícones no mapa.
        });
    });

    // 3. FECHAR A LISTA SE CLICAR FORA (No mapa ou no rodapé)
    document.addEventListener('click', (e) => {
        if (!inputFiltro.contains(e.target) && !listaSugestoes.contains(e.target)) {
            listaSugestoes.style.display = 'none';
        }
    });
});