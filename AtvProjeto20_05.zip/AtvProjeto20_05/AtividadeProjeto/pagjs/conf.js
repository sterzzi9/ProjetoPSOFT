document.addEventListener('DOMContentLoaded', () => {
    const btnMenu = document.getElementById('abrir-menu');
    const btnFecharMenu = document.getElementById('fechar-menu');
    const sidebar = document.getElementById('menu-lateral');
    const overlay = document.getElementById('fundo-escuro');

    const btnPerfil = document.getElementById('abrir-perfil');
    const menuPerfil = document.getElementById('perfil-menu');

    const inputFiltro = document.getElementById('filtro');
    const listaSugestoes = document.getElementById('lista');

    // --- LOGICA MENU LATERAL ---
    btnMenu.addEventListener('click', () => {
        sidebar.classList.add('aberto');
        overlay.classList.add('ativo');
    });

    const fecharTudo = () => {
        sidebar.classList.remove('aberto');
        overlay.classList.remove('ativo');
        menuPerfil.classList.remove('mostrar');
    };

    btnFecharMenu.addEventListener('click', fecharTudo);
    overlay.addEventListener('click', fecharTudo);

    // --- LOGICA PERFIL ---
    btnPerfil.addEventListener('click', (e) => {
        e.stopPropagation();
        menuPerfil.classList.toggle('mostrar');
    });

    // --- LOGICA BUSCA ---
    inputFiltro.addEventListener('input', () => {
        if (inputFiltro.value.length > 0) {
            listaSugestoes.classList.add('mostrar');
        } else {
            listaSugestoes.classList.remove('mostrar');
        }
    });

    // Clicar fora fecha os menus pequenos
    document.addEventListener('click', () => {
        menuPerfil.classList.remove('mostrar');
        listaSugestoes.classList.remove('mostrar');
    });
});